<?php
/*
Plugin Name: Customizer Sync
Description: Used for importing/exporting customizer options.
Author:	MerryCode
Version: 1.0
*/

function merrycode_cie_page_function()
{
	global $wpdb;
	echo "<h3>Customizer Data Import/Export</h3>";
	set_theme_mod( "customizer_sync_installed", "true" );

	$options_table_name="wp_options";

	$options_table_name= $wpdb->prefix."options";
	


	if(isset($_POST['merrycode_cie_data']) && isset($_POST['i-understand']))
	{
		$wpdb->update( $options_table_name, array('option_value' => stripslashes($_POST['merrycode_cie_data'])), array('option_name' => 'theme_mods_MerryCafe'), $format = null, $where_format = null );
		echo "<div style='width:100%'><b><h4>Customizer Data Updated!</h4></b></div>";
	}

	$current_theme=wp_get_theme();

	$theme_name=$current_theme->get('Name');

	global $wpdb;
	$results = $wpdb->get_results( "SELECT option_value FROM ".$options_table_name." WHERE option_name = 'theme_mods_".$theme_name."'", OBJECT );

	echo "<div style='width:100%;float:left; margin-bottom:30px'><b>We don't mean to scare you or something</b> but be careful here please. Once you update, everything in customizer options is erased and updated with new customizer options you enter here.<br/><b>It is recommended to backup your current data</b> by copy/pasting it somewhere before you replace it.</div>";
	
	echo "<form method='post'>";
	
	echo "<textarea name='merrycode_cie_data' style='width: 600px;height: 150px;'>".$results[0]->option_value."</textarea>";
	echo "<div style='width:100%'><input type='checkbox' name='i-understand' style='margin-top:20px;margin-bottom: 20px;'/><b>Check this to approve the update.</b> </div> ";
	echo "<div style='width:100%'><input value='Update Customizer Options' type='submit' class='button-primary'</div>";
	

	echo "</form>";

	

}

//Admin menu addition
function merrycode_cie_menu_page() {
    add_menu_page (
        'Customizer Sync',
        'Customizer Sync',
        'manage_options',
        'cie_manager',
        'merrycode_cie_page_function',
      'dashicons-update',
        '100'
    );
}

add_action( 'admin_menu', 'merrycode_cie_menu_page' );
?>